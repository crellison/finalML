from PIL import Image


def get_normalized_image(image_path):
    with Image.open(image_path) as image:
        new_height =
        resized_image = Image.resize(800, 800)
